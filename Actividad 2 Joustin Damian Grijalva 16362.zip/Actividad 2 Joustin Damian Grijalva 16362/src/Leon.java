public class Leon extends Zoo{
    public void vacuna(){
        System.out.println("El león, al igual que otros animales\n si están vacunados.");
    }

    public Leon(String nombreAnimal, int edad){
        super(nombreAnimal, edad);
    }

    public void rugir(){
        System.out.println("El leon puede rugir.");
    }

    public void cazar(){
        System.out.println("No lo distraigas está cazando");
    }

}
